copy the file to any drive and then from cmd  execute below command
java -jar rane-0.0.1-SNAPSHOT.jar

then you will be able toconsume services via postman/ any ui

to check the request paramaters use this 
http://localhost:8009/api.html

for db tables verification 
http://localhost:8009/h2-console/
password - admin

npm install --save @angular/material@14


      @angular/cli                       16.2.0 -> 17.0.7         ng update @angular/cli
      @angular/core                      16.2.0 -> 17.0.7         ng update @angular/core

http://localhost:8009/api/save
[{
	"name":"user1",
	"gaugeValue":"20",
	"gaugeLabel":"% Of First off Yield"
},
{
	"name":"user2",
	"gaugeValue":"40",
	"gaugeLabel":"% Of OEE"
},
{
	"name":"user3",
	"gaugeValue":"40",
	"gaugeLabel":"% Of Rework"
},
{
	"name":"user4",
	"gaugeValue":"40",
	"gaugeLabel":"No of customer complaints /month"
}
]