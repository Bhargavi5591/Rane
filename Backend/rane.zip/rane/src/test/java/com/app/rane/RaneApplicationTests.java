package com.app.rane;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RaneApplicationTests {

	@Test
	void contextLoads() {
	}

}
