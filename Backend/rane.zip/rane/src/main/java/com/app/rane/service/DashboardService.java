package com.app.rane.service;

import java.util.List;

import com.app.rane.entity.Dashboard;

public interface DashboardService {
	List<Dashboard> getDashboardContent();
	void saveDashboardContent(List<Dashboard> contentList);
}
