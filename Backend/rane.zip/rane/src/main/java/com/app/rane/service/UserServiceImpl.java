package com.app.rane.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.rane.entity.User;
import com.app.rane.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;
	
	public User getUser(String name) {
		Optional<User> optionalUser=userRepository.findByName(name);
		return optionalUser.get();
	}

	
	public User loginUser(User user) {
		return userRepository.save(user);
	}

}
