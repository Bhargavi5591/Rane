package com.app.rane.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;

import com.app.rane.entity.File;
import com.app.rane.service.FileStorageService;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping(value = "/api")
@Tag(name = "File Upload", description = "Upload API")
@CrossOrigin("*")
public class FilesController {
	@Autowired
	FileStorageService fileStorageService;

	@PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE, value = "/upload")
	public ResponseEntity<?> upload(@RequestParam("files") MultipartFile[] files,
			@RequestParam("username") String userName,
			@RequestParam("module") String module,
			@RequestParam("operator") String operator,
			@RequestParam("optionId") int optionId,
			@RequestParam("option") String option) {
		try {
			List<String> fileNames = new ArrayList<>();
			Arrays.asList(files).stream().forEach(file -> {
				fileStorageService.save(file,userName,module,operator,optionId,option);
				fileNames.add(file.getOriginalFilename());
			});
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}

	}

	@GetMapping("/downloadFile/{option}")
	public ResponseEntity<?> getFileByName(@PathVariable String option) {
		File file = fileStorageService.getFileByOption(option);
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(file.getFileType()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFileName() + "\"")
				.body(new ByteArrayResource(file.getFile()));

	}
	  
	@DeleteMapping("/deletefile/{optionId}")
	 public ResponseEntity<?> delete(
	      @PathVariable("optionId") int optionId)
	       {
		try {
			this.fileStorageService.delete(optionId);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (Exception e) {
			System.out.println(e.getMessage());
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	
	  }
}
