package com.app.rane.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.rane.entity.User;
import com.app.rane.service.UserService;

import io.swagger.v3.oas.annotations.tags.Tag;



@RestController
@RequestMapping("/api")
@Tag(name = "User", description = "User login/forgot APIs")
public class UserController {

	@Autowired
	UserService userService;

	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody User user) {
		if(user.getName().equals("admin")&& user.getPassword().equals("admin")) {
			User savedUser = userService.loginUser(user);
			return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
		}
		return new ResponseEntity<>("login Failed",HttpStatus.BAD_REQUEST);

	}
	 
	@GetMapping("/forgotpassword/{name}")
	public ResponseEntity<?> getForgetPassword(@PathVariable("name") String username) {
		User user = userService.getUser(username);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
}
