package com.app.rane.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.app.rane.entity.File;
import com.app.rane.exception.RaneException;
import com.app.rane.repository.FileRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class FileStorageServiceImpl implements FileStorageService {
	
	@Autowired
	private FileRepository fileRepository;


	public void save(MultipartFile file, String userName,String module, String operator,int optionId, String option) {
	    try {
	    	File fileInput=new File();
	    	fileInput.setFile(file.getBytes());
	    	fileInput.setFileName(file.getOriginalFilename());
	    	fileInput.setFileType(file.getContentType());
	    	fileInput.setUserName(userName);
	    	fileInput.setModule(module);
	    	fileInput.setOperator(operator);
	    	fileInput.setOption(option);
	    	fileInput.setOptionId(optionId);
	    	fileRepository.save(fileInput);
	      } catch (Exception e) {
	        throw new RuntimeException("Could not store the file. Error: " + e.getMessage());
	      }
		
	}


	@Override
	public File getFileByOption(String option) {
		
		File file=fileRepository.findByOption(option).get();
		return file;
	}


	@Override
	public void delete(int optionId) throws RaneException {
		final Optional<File> file =this.fileRepository.findByOptionId(optionId);
		if(file.isPresent()) {
			File fileresult=file.get();
			System.out.println(fileresult.getOption());
			System.out.println(optionId);
			System.out.println(fileresult.getOptionId());
			fileRepository.deleteByOptionId(optionId);
		}else {
			System.out.println("File Not Found!!");
			throw RaneException.internalError("File Not Found!!");
		}	
	}

}
