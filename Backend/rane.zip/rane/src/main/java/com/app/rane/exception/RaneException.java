package com.app.rane.exception;

public class RaneException extends Exception {
	  private final ErrorCode errorCode;
	  private final String errorDescription;

	  public RaneException(final ErrorCode errorCode, final String errorDescription) {
	    this.errorDescription = errorDescription;
	    this.errorCode = errorCode;
	  }

	  public static RaneException internalError(final String errorDescription) {
	    return new RaneException(ErrorCode.INTERNAL_ERROR, errorDescription);
	  }

	  public static RaneException badRequest(final String errorDescription) {
	    return new RaneException(ErrorCode.BAD_REQUEST, errorDescription);
	  }

	  public static RaneException communicationError(final String errorDescription) {
	    return new RaneException(ErrorCode.COMMUNICATION_ERROR, errorDescription);
	  }

	  public static RaneException authorizationError(final String errorDescription) {
	    return new RaneException(ErrorCode.AUTHORIZATION_ERROR, errorDescription);
	  }

	  public String getErrorDescription() {
	    return errorDescription;
	  }

	  public ErrorCode getErrorCode() {
	    return errorCode;
	  }

}
