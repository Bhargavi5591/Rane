package com.app.rane.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Dashboard {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	private String gaugeValue;
	private String gaugeLabel;
	public Dashboard() {}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGaugeValue() {
		return gaugeValue;
	}
	public void setGaugeValue(String gaugeValue) {
		this.gaugeValue = gaugeValue;
	}
	public String getGaugeLabel() {
		return gaugeLabel;
	}
	public void setGaugeLabel(String gaugeLabel) {
		this.gaugeLabel = gaugeLabel;
	}
	public Dashboard(long id, String name, String gaugeValue, String gaugeLabel) {
		super();
		this.id = id;
		this.name = name;
		this.gaugeValue = gaugeValue;
		this.gaugeLabel = gaugeLabel;
	}
	@Override
	public String toString() {
		return "Dashboard [id=" + id + ", name=" + name + ", gaugeValue=" + gaugeValue + ", gaugeLabel=" + gaugeLabel
				+ "]";
	}
	
}
