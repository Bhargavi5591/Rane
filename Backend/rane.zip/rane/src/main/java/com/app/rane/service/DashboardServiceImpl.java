package com.app.rane.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.rane.entity.Dashboard;
import com.app.rane.repository.DashboardRepository;

@Service
public class DashboardServiceImpl implements DashboardService{

	@Autowired
	DashboardRepository dashboardRepository;
	
	@Override
	public List<Dashboard> getDashboardContent() {		
		return dashboardRepository.findAll();
	}

	@Override
	public void saveDashboardContent(List<Dashboard> contentList) {
		for(Dashboard content:contentList) {
			dashboardRepository.save(content);
		}
		
	}

}
