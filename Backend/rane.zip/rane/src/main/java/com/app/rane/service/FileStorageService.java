package com.app.rane.service;

import org.springframework.web.multipart.MultipartFile;

import com.app.rane.entity.File;
import com.app.rane.exception.RaneException;

public interface FileStorageService {

	public void save(MultipartFile file, String userName,String module, String operator, int optionId, String option);
	public File getFileByOption(String option);
	public void delete(int optionId) throws RaneException;
	

}
