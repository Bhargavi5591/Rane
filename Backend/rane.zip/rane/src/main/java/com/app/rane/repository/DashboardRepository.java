package com.app.rane.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.rane.entity.Dashboard;


public interface DashboardRepository extends JpaRepository<Dashboard, Integer>{

}
