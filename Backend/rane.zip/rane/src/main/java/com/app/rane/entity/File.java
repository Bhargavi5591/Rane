package com.app.rane.entity;


import java.time.LocalDateTime;
import java.util.Arrays;

import org.springframework.data.annotation.CreatedDate;

import jakarta.persistence.*;


@Entity
public class File {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String userName;
	private String module;
	private int optionId;
	private String option;
	private String operator;
	private String fileName;
	private String fileType;
	@Lob
	private byte[] file;

	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime  timestamp;	
	

	
	public File(long id, String userName, String module, int optionId, String option, String operator, String fileName,
			String fileType, byte[] file, LocalDateTime timestamp) {
		super();
		this.id = id;
		this.userName = userName;
		this.module = module;
		this.optionId = optionId;
		this.option = option;
		this.operator = operator;
		this.fileName = fileName;
		this.fileType = fileType;
		this.file = file;
		this.timestamp = timestamp;
	}



	@Override
	public String toString() {
		return "File [id=" + id + ", userName=" + userName + ", module=" + module + ", optionId=" + optionId
				+ ", option=" + option + ", operator=" + operator + ", fileName=" + fileName + ", fileType=" + fileType
				+ ", file=" + Arrays.toString(file) + ", timestamp=" + timestamp + "]";
	}



	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getModule() {
		return module;
	}



	public void setModule(String module) {
		this.module = module;
	}



	public int getOptionId() {
		return optionId;
	}



	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}



	public String getOption() {
		return option;
	}



	public void setOption(String option) {
		this.option = option;
	}



	public String getOperator() {
		return operator;
	}



	public void setOperator(String operator) {
		this.operator = operator;
	}



	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public String getFileType() {
		return fileType;
	}



	public void setFileType(String fileType) {
		this.fileType = fileType;
	}



	public byte[] getFile() {
		return file;
	}



	public void setFile(byte[] file) {
		this.file = file;
	}



	public LocalDateTime getTimestamp() {
		return timestamp;
	}



	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}



	public File() {
		this.timestamp = LocalDateTime.now();
	}
}
