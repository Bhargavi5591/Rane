package com.app.rane.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.rane.entity.Dashboard;
import com.app.rane.service.DashboardService;


import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/api")
@Tag(name = "Dashboard", description = "KPI Dashboard APIs")
public class DashboardController {

	@Autowired
	DashboardService dashboardService;

	
	@PostMapping("/save")
	public ResponseEntity<?> save(@RequestBody List<Dashboard> contentList) {
		dashboardService.saveDashboardContent(contentList);
		return new ResponseEntity<>("save successfully", HttpStatus.CREATED);
	}
	
	@GetMapping("/getkpicontent")
	public ResponseEntity<?> getKpiContent() {
		List<Dashboard> contentList=dashboardService.getDashboardContent();
		return new ResponseEntity<>(contentList, HttpStatus.OK);
	}
}
