package com.app.rane.exception;

public enum ErrorCode {
	  INTERNAL_ERROR,
	  BAD_REQUEST,
	  COMMUNICATION_ERROR,
	  AUTHORIZATION_ERROR;
	}
