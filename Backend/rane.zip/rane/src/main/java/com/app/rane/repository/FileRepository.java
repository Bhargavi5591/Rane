package com.app.rane.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.rane.entity.File;

public interface FileRepository extends JpaRepository<File, Integer>{
	Optional<File> findByOption(String option);

	void deleteByOptionId(int optionId);

	Optional<File> findByOptionId(int optionId);

}
