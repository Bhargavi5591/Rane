package com.app.rane.service;

import com.app.rane.entity.User;

public interface UserService {
	User loginUser(User user);
	User getUser(String name);

}
